package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Represents a product in the inventory system.
 * Each product has an ID, name, price, stock level, minimum, and maximum allowed stock.
 * A product can also have associated parts that make up the product.
 */
public class Product {
    // Observable list of associated parts for the product
    private final ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    /**
     * Constructs a new Product with the specified details.
     *
     * @param id the unique identifier for the product
     * @param name the name of the product
     * @param price the price of the product
     * @param stock the current stock level of the product
     * @param min the minimum allowable stock level
     * @param max the maximum allowable stock level
     */
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /**
     * Removes the specified associated part from the product's list of associated parts.
     *
     * @param selectedAssociatedPart the part to be removed
     * @return true if the part was successfully removed, false otherwise
     */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart) {
        return associatedParts.remove(selectedAssociatedPart);
    }

    /**
     * Gets the list of associated parts for this product.
     *
     * @return the observable list of associated parts
     */
    public ObservableList<Part> getAllAssociatedParts() {
        return associatedParts;
    }

    /**
     * Adds a part to the product's list of associated parts.
     *
     * @param part the part to be added
     */
    public void addAssociatedPart(Part part) {
        associatedParts.add(part);
    }

    /**
     * Gets the product's ID.
     *
     * @return the product ID
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the product's ID.
     *
     * @param id the new product ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the product's name.
     *
     * @return the product name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the product's name.
     *
     * @param name the new product name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the product's price.
     *
     * @return the product price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Sets the product's price.
     *
     * @param price the new product price
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Gets the current stock level of the product.
     *
     * @return the current stock level
     */
    public int getStock() {
        return stock;
    }

    /**
     * Sets the current stock level of the product.
     *
     * @param stock the new stock level
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * Gets the minimum allowable stock level for the product.
     *
     * @return the minimum stock level
     */
    public int getMin() {
        return min;
    }

    /**
     * Sets the minimum allowable stock level for the product.
     *
     * @param min the new minimum stock level
     */
    public void setMin(int min) {
        this.min = min;
    }

    /**
     * Gets the maximum allowable stock level for the product.
     *
     * @return the maximum stock level
     */
    public int getMax() {
        return max;
    }

    /**
     * Sets the maximum allowable stock level for the product.
     *
     * @param max the new maximum stock level
     */
    public void setMax(int max) {
        this.max = max;
    }
}