package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * The Inventory class is responsible for managing collections of parts and products in the inventory.
 * It provides methods to add, modify, remove, and search for parts and products.
 */
public class Inventory {

    // Observable lists to store the parts and products in the inventory
    private static final ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static final ObservableList<Product> allProducts = FXCollections.observableArrayList();

    /**
     * Adds a new part to the inventory.
     *
     * @param newPart the part to be added to the inventory
     */
    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }

    /**
     * Returns the list of parts in the inventory.
     *
     * @return an observable list of parts
     */
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    /**
     * Adds a new product to the inventory.
     *
     * @param newProduct the product to be added to the inventory
     */
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    /**
     * Returns the list of products in the inventory.
     *
     * @return an observable list of products
     */
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

    /**
     * Searches for parts in the inventory that contain the specified partial name.
     *
     * @param partialName the partial name to search for
     * @return a list of parts that match the search criteria
     */
    public static ObservableList<Part> lookupPartName(String partialName) {
        ObservableList<Part> namedPart = FXCollections.observableArrayList();
        for (Part gp : Inventory.getAllParts()) {
            if (gp.getName().toLowerCase().contains(partialName.toLowerCase())) {
                namedPart.add(gp);
            }
        }
        return namedPart;
    }

    /**
     * Modifies an existing part in the inventory.
     *
     * @param index the index of the part to modify
     * @param updatePart the modified part to replace the existing one
     */
    public static void updatePart(int index, Part updatePart) {
        allParts.set(index, updatePart);
    }

    /**
     * Modifies an existing product in the inventory.
     *
     * @param index the index of the product to modify
     * @param updateProduct the modified product to replace the existing one
     */
    public static void updateProduct(int index, Product updateProduct) {
        allProducts.set(index, updateProduct);
    }

    /**
     * Removes the specified part from the inventory.
     *
     * @param selectedPart the part to be removed
     * @return true if the part was removed, false otherwise
     */
    public static boolean deletePart(Part selectedPart) {
        return allParts.remove(selectedPart);
    }

    /**
     * Removes the specified product from the inventory.
     *
     * @param selectedProduct the product to be removed
     * @return true if the product was removed, false otherwise
     */
    public static boolean deleteProduct(Product selectedProduct) {
        return allProducts.remove(selectedProduct);
    }

    /**
     * Searches for a part in the inventory by its ID.
     *
     * @param partID the ID of the part to search for
     * @return the part with the matching ID, or null if not found
     */
    public static Part lookupPartID(int partID) {
        for (Part inventoryPart : allParts) {
            if (inventoryPart.getId() == partID) {
                return inventoryPart;
            }
        }
        return null;
    }

    /**
     * Searches for products in the inventory that contain the specified partial name.
     *
     * @param partialName the partial name to search for
     * @return a list of products that match the search criteria
     */
    public static ObservableList<Product> lookupProductName(String partialName) {
        ObservableList<Product> namedProduct = FXCollections.observableArrayList();
        for (Product gp : Inventory.getAllProducts()) {
            if (gp.getName().toLowerCase().contains(partialName.toLowerCase())) {
                namedProduct.add(gp);
            }
        }
        return namedProduct;
    }

    /**
     * Searches for a product in the inventory by its ID.
     *
     * @param productID the ID of the product to search for
     * @return the product with the matching ID, or null if not found
     */
    public static Product lookupProductID(int productID) {
        for (Product inventoryProduct : allProducts) {
            if (inventoryProduct.getId() == productID) {
                return inventoryProduct;
            }
        }
        return null;
    }
}