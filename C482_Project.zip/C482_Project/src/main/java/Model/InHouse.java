package Model;

/**
 * The InHouse class represents a part that is manufactured in-house and inherits from the Part class.
 * This class includes the additional attribute machineID, which tracks the ID of the machine used to manufacture the part.
 */
public class InHouse extends Part {

    // The ID of the machine used to manufacture the part
    private int machineID;

    /**
     * Constructs a new InHouse part with the specified details.
     *
     * @param id the unique identifier for the part
     * @param name the name of the part
     * @param price the price of the part
     * @param stock the current stock level of the part
     * @param min the minimum allowable stock level
     * @param max the maximum allowable stock level
     * @param machineID the ID of the machine that produced the part
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineID) {
        super(id, name, price, stock, min, max);
        this.machineID = machineID;
    }

    /**
     * Gets the machine ID for this in-house part.
     *
     * @return the machine ID
     */
    public int getMachineID() {
        return machineID;
    }

    /**
     * Sets the machine ID for this in-house part.
     *
     * @param machineID the new machine ID to set
     */
    public void setMachineID(int machineID) {
        this.machineID = machineID;
    }
}