package Model;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

/**
 * Main class for the Inventory Management Application.
 * This class initializes the application, loads test data, and starts the main stage.
 */
public class Main extends Application {

    /**
     * Main method that loads test data for parts and products into the inventory.
     * The application is then launched.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        // Creating sample parts
        InHouse part = new InHouse(1, "Big Wheel", 11, 1, 0, 100, 4);
        InHouse part1 = new InHouse(2, "Small Wheel", 22, 20, 1, 60, 5);
        InHouse part2 = new InHouse(3, "Brake", 33, 16, 8, 16, 4);
        Outsourced part3 = new Outsourced(4, "Radio", 44, 2, 0, 25, "Andersons");
        Outsourced part4 = new Outsourced(5, "Cushion Seat", 55, 4, 0, 48, "Platt");
        Outsourced part5 = new Outsourced(6, "Window", 66, 4, 0, 100, "Dodge");

        // Creating sample products
        Product product = new Product(1, "Square Window", 123, 3, 1, 40);
        Product product1 = new Product(2, "Circular Window", 456, 7, 1, 100);
        Product product2 = new Product(2, "rectangle Window", 789, 11, 1, 25);

        // Adding parts to the inventory
        Inventory.addPart(part);
        Inventory.addPart(part1);
        Inventory.addPart(part2);
        Inventory.addPart(part3);
        Inventory.addPart(part4);
        Inventory.addPart(part5);

        // Associating parts with products
        product.addAssociatedPart(part);
        product.addAssociatedPart(part1);
        product.addAssociatedPart(part2);
        product.addAssociatedPart(part3);
        product.addAssociatedPart(part4);
        product1.addAssociatedPart(part1);
        product1.addAssociatedPart(part2);
        product1.addAssociatedPart(part3);
        product1.addAssociatedPart(part5);

        // Adding products to the inventory
        Inventory.addProduct(product);
        Inventory.addProduct(product1);
        Inventory.addProduct(product2);

        // Launching the JavaFX application
        launch(args);
    }

    /**
     * Initializes the JavaFX stage and loads the Main.fxml file to display the main application window.
     *
     * @param primaryStage the primary stage for this application
     * @throws Exception if an error occurs during FXML loading
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Loading the FXML file for the main scene
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/View/Main.fxml")));

        // Setting up the stage with title and scene
        primaryStage.setTitle("Inventory Manager");
        primaryStage.setScene(new Scene(root, 800, 450));

        // Displaying the stage
        primaryStage.show();
    }
}