package Model;

/**
 * The Outsourced class represents a part that is produced by an external company.
 * This class inherits from the Part class and adds the company name attribute.
 */
public class Outsourced extends Part {
    private String companyName;

    /**
     * Constructs a new Outsourced part with the specified details.
     *
     * @param id the unique identifier for the part
     * @param name the name of the part
     * @param price the price of the part
     * @param stock the current stock level of the part
     * @param min the minimum allowable stock level
     * @param max the maximum allowable stock level
     * @param companyName the name of the company that produces the part
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }

    /**
     * Gets the name of the company that produces the part.
     *
     * @return the company name
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Sets the name of the company that produces the part.
     *
     * @param companyName the company name to set
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
