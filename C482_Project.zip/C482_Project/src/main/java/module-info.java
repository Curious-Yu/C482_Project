module project482.c482_project {
    requires javafx.controls;
    requires javafx.fxml;


//    opens project482.c482_project to javafx.fxml;
//    exports project482.c482_project;
    exports Controller;
    opens Controller to javafx.fxml;
    exports Model;
    opens Model to javafx.fxml;
}