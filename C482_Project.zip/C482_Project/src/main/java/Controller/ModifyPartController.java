package Controller;

import Model.InHouse;
import Model.Inventory;
import Model.Outsourced;
import Model.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller class for the ModifyPart.fxml view.
 * Manages interactions related to modifying an existing part, including handling data input and toggling between InHouse and Outsourced part types.
 */
public class ModifyPartController {

    public Label idNameToggle;
    public TextField inventorySection;
    public TextField nameSection;
    public TextField priceSection;
    public TextField minSection;
    public TextField maxSection;
    public TextField idSection;
    public TextField idNameSection;
    public RadioButton inHouse;
    public RadioButton outSourced;
    public Label errorLabel;
    public int mpIndex;

    /**
     * This method updates the label to "Machine ID" when the InHouse radio button is selected.
     *
     * @param actionEvent the action event triggered by selecting the InHouse radio button
     */
    public void inHouseSelect(ActionEvent actionEvent) {
        idNameToggle.setText("Machine ID");
    }

    /**
     * This method updates the label to "Company Name" when the Outsourced radio button is selected.
     *
     * @param actionEvent the action event triggered by selecting the Outsourced radio button
     */
    public void outSourcedSelect(ActionEvent actionEvent) {
        idNameToggle.setText("Company Name");
    }

    /**
     * This method handles the data input and modifies the selected part when the modify button is pressed.
     * Displays an error alert if the data is invalid.
     *
     * @param actionEvent the action event triggered by pressing the modify button
     */
    public void modifyButtonAction(ActionEvent actionEvent) {
        try {
            int id = Integer.parseInt(idSection.getText().trim());
            String name = nameSection.getText().trim();
            int stock = Integer.parseInt(inventorySection.getText().trim());
            double price = Double.parseDouble(priceSection.getText().trim());
            int min = Integer.parseInt(minSection.getText().trim());
            int max = Integer.parseInt(maxSection.getText().trim());

            if (min > max) {
                showAlert(Alert.AlertType.ERROR, "Error", "The min must be less than the max");
                return;
            }

            if (stock > max || stock < min) {
                showAlert(Alert.AlertType.ERROR, "Error", "Stock cannot be more than max or less than min");
                return;
            }

            if (inHouse.isSelected()) {
                int machineID = Integer.parseInt(idNameSection.getText());
                InHouse modifiedPart = new InHouse(id, name, price, stock, min, max, machineID);
                Inventory.updatePart(mpIndex, modifiedPart);
            } else if (outSourced.isSelected()) {
                String companyName = idNameSection.getText();
                Outsourced modifiedPart = new Outsourced(id, name, price, stock, min, max, companyName);
                Inventory.updatePart(mpIndex, modifiedPart);
            }
            cancelButton(actionEvent);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid data entered");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load the main view");
        }
    }

    /**
     * This method returns the user to the Main.fxml view without saving any user input.
     *
     * @param actionEvent the action event triggered by pressing the cancel button
     * @throws IOException if an I/O error occurs during navigation
     */
    public void cancelButton(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Main.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 800, 450);
        stage.setTitle("Inventory Manager");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method populates the fields with the data from the provided part when the ModifyPartController is launched.
     *
     * @param part the part to be modified
     */
    public void sendProductData(Part part) {
        if (part instanceof Outsourced) {
            outSourced.setSelected(true);
            idNameToggle.setText("Company Name");
            idNameSection.setText(((Outsourced) part).getCompanyName());
        } else if (part instanceof InHouse) {
            inHouse.setSelected(true);
            idNameSection.setText(Integer.toString(((InHouse) part).getMachineID()));
        }
        idSection.setText(Integer.toString(part.getId()));
        inventorySection.setText(Integer.toString(part.getStock()));
        nameSection.setText(part.getName());
        priceSection.setText(Double.toString(part.getPrice()));
        minSection.setText(Integer.toString(part.getMin()));
        maxSection.setText(Integer.toString(part.getMax()));
        mpIndex = Inventory.getAllParts().indexOf(part);
    }

    /**
     * This method displays an alert with the specified type, title, and content text.
     *
     * @param alertType the type of alert to display
     * @param title     the title of the alert
     * @param content   the content text of the alert
     */
    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}