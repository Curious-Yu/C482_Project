package Controller;

import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller class for the Main.fxml view.
 * Included Future Improvement and Runtime Error.
 * Handles interactions with the parts and products tables, including adding, modifying, and deleting parts and products.
 */
public class MainController implements Initializable {

    // Parts TableView and columns
    public TableView<Part> partTableView;
    public TableColumn<Part, Integer> mainPartID;
    public TableColumn<Part, String> mainPartName;
    public TableColumn<Part, Integer> mainPartInventory;
    public TableColumn<Part, Double> mainPartPrice;

    // Products TableView and columns
    public TableView<Product> productTableView;
    public TableColumn<Product, Integer> mainProductID;
    public TableColumn<Product, String> mainProductName;
    public TableColumn<Product, Integer> mainProductInventory;
    public TableColumn<Product, Double> mainProductPrice;

    // UI components
    public AnchorPane anchorPane;
    public TextField searchPart;
    public TextField searchProduct;
    public Button exitButton;

    /**
     * This method initializes the tables with data from the Inventory model.
     * @param url the location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle the resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Set up Part Table columns
        mainPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        mainPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        mainPartInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        mainPartPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        partTableView.setItems(Inventory.getAllParts());

        // Set up Product Table columns
        mainProductID.setCellValueFactory(new PropertyValueFactory<>("id"));
        mainProductName.setCellValueFactory(new PropertyValueFactory<>("name"));
        mainProductInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        mainProductPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        productTableView.setItems(Inventory.getAllProducts());
    }

    /**
     * This method opens the AddPart.fxml view to add a new part.
     * @param actionEvent the action event that triggered this method.
     * @throws IOException if an I/O error occurs during the loading of the FXML file.
     */
    public void addPartsAction(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View/AddPart.fxml"));
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 400, 600);
        stage.setTitle("Add Part");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method opens the ModifyPart.fxml view to modify the selected part.
     * @param actionEvent the action event that triggered this method.
     * @throws IOException if an I/O error occurs during the loading of the FXML file.
     */
    public void modifyPartsAction(ActionEvent actionEvent) throws IOException {
        Part selectedPart = partTableView.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View/ModifyPart.fxml"));
            Parent scene = loader.load();
            ModifyPartController controller = loader.getController();
            controller.sendProductData(selectedPart);
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(new Scene(scene));
            stage.show();
        } else {
            showAlert(Alert.AlertType.ERROR, "Error!", "Please make a selection.");
        }
    }

    /**
     * This method deletes the selected part after user confirmation.
     * @param actionEvent the action event that triggered this method.
     */
    public void deletePartsAction(ActionEvent actionEvent) {
        Part selectedPart = partTableView.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setContentText("Are you sure?");
            alert.setHeaderText("Delete " + selectedPart.getName());
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                Inventory.deletePart(selectedPart);
                partTableView.setItems(Inventory.getAllParts());
                // Remove part from associated products
                for (Product product : Inventory.getAllProducts()) {
                    if (product.getAllAssociatedParts().contains(selectedPart)) {
                        product.deleteAssociatedPart(selectedPart);
                    }
                }
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Error!", "Please make a selection.");
        }
    }

    /**
     * This method opens the AddProduct.fxml view to add a new product.
     * @param actionEvent the action event that triggered this method.
     * @throws IOException if an I/O error occurs during the loading of the FXML file.
     */
    public void addProductsAction(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View/AddProduct.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 950, 600);
        stage.setTitle("Add Product");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method opens the ModifyProduct.fxml view to modify the selected product.
     * @param actionEvent the action event that triggered this method.
     * @throws IOException if an I/O error occurs during the loading of the FXML file.
     */
    public void modifyProductsAction(ActionEvent actionEvent) throws IOException {
        Product selectedProduct = productTableView.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View/ModifyProduct.fxml"));
            Parent scene = loader.load();
            ModifyProductController controller = loader.getController();
            controller.sendProductData(selectedProduct);
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(new Scene(scene));
            stage.show();
        } else {
            showAlert(Alert.AlertType.ERROR, "Error!", "Please make a selection.");
        }
    }

    /**
     * This method deletes the selected product after user confirmation.
     * Products with associated parts cannot be deleted.
     * @param actionEvent the action event that triggered this method
     */
    public void deleteProductsAction(ActionEvent actionEvent) {
        Product selectedProduct = productTableView.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            if (selectedProduct.getAllAssociatedParts().isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setContentText("Are you sure?");
                alert.setHeaderText("Delete " + selectedProduct.getName());
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    Inventory.deleteProduct(selectedProduct);
                    productTableView.setItems(Inventory.getAllProducts());
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", selectedProduct.getName() + " cannot be deleted as it has associated parts.");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Error!", "Please make a selection.");
        }
    }

    /**
     * FUTURE ENHANCEMENT: Implement fuzzy search for parts and products.
     * <p>
     * Enhance the search functionality to handle partial matches and fuzzy searches, providing better results for users with incomplete or incorrect search queries.
     */

    /**
     * RUNTIME ERROR:
     * <p>
     * Problem: Constantly having the "No content in table." message and empty table when doing search due to the search logic does not correctly handle cases where the query does not match the expected patterns.
     * <p>
     * Solution:
     * <p>
     * Handling Empty Query - The code checks if query is empty and sets the partTableView (productTableView) items to allParts (allProducts), effectively showing all products when no search criteria are provided.
     * <p>
     * Handling Numeric IDs - The code uses query.matches("[0-9]+") to determine if the search query is a numeric ID. It then parses the query into an integer and filters products based on this ID. This ensures that only products matching the numeric ID are displayed.
     * <p>
     * Handling Product Names - The code uses query.matches("[a-zA-Z]+") to determine if the search query is a name. It filters products by comparing the query with the product names, ensuring case-insensitive matching.
     */

    /**
     * This method searches for parts based on the input text.
     * @param actionEvent the action event that triggered this method
     */

    public void searchPartAction(ActionEvent actionEvent) {
        String query = searchPart.getText().trim();
        ObservableList<Part> allParts = Inventory.getAllParts();

        // Show all parts if the search query is empty
        if (query.isEmpty()) {
            partTableView.setItems(allParts);
            return;
        }

        // Handle search for numeric IDs
        if (query.matches("[0-9]+")) {
            int id = Integer.parseInt(query);
            ObservableList<Part> partsById = FXCollections.observableArrayList();
            for (Part part : allParts) {
                if (part.getId() == id) {
                    partsById.add(part);
                }
            }
            partTableView.setItems(partsById);
            return;
        }

        // Handle search for part names
        if (query.matches("[a-zA-Z]+")) {
            ObservableList<Part> partsByName = FXCollections.observableArrayList();
            for (Part part : allParts) {
                if (part.getName().toLowerCase().contains(query.toLowerCase())) {
                    partsByName.add(part);
                }
            }
            partTableView.setItems(partsByName);
            return;
        }

        // If query does not match any criteria, clear the table
        partTableView.setItems(FXCollections.observableArrayList());
    }

    /**
     * This method searches for products based on the input text and updates the product table accordingly.
     * @param actionEvent the action event that triggered this method
     */
    public void searchProductAction(ActionEvent actionEvent) {
        String query = searchProduct.getText().trim();
        ObservableList<Product> allProducts = Inventory.getAllProducts();

        // Show all products if the search query is empty
        if (query.isEmpty()) {
            productTableView.setItems(allProducts);
            return;
        }

        // Handle search for numeric IDs
        if (query.matches("[0-9]+")) {
            int id = Integer.parseInt(query);
            ObservableList<Product> productsById = FXCollections.observableArrayList();
            for (Product product : allProducts) {
                if (product.getId() == id) {
                    productsById.add(product);
                }
            }
            productTableView.setItems(productsById);
            return;
        }

        // Handle search for product names
        if (query.matches("[a-zA-Z]+")) {
            ObservableList<Product> productsByName = FXCollections.observableArrayList();
            for (Product product : allProducts) {
                if (product.getName().toLowerCase().contains(query.toLowerCase())) {
                    productsByName.add(product);
                }
            }
            productTableView.setItems(productsByName);
            return;
        }

        // If query does not match any criteria, clear the table
        productTableView.setItems(FXCollections.observableArrayList());
    }

    /**
     * This method exits the application.
     * @param actionEvent the action event that triggered this method
     */
    public void exitButton(ActionEvent actionEvent) {
        System.exit(0);
    }

    /**
     * This method displays an alert with the specified type, title, and content text.
     *
     * @param alertType the type of alert to display
     * @param title     the title of the alert
     * @param content   the content text of the alert
     */
    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}