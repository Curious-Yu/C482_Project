package Controller;

import Model.InHouse;
import Model.Inventory;
import Model.Outsourced;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller class for the AddPart.fxml view.
 * Handles interactions for adding new parts, including switching between in-house and outsourced parts.
 */
public class AddPartController {

    public Label idNameToggle;
    public TextField inventorySection;
    public TextField nameSection;
    public TextField priceSection;
    public TextField minSection;
    public TextField maxSection;
    public TextField idNameSection;
    public RadioButton inHouse;
    public RadioButton outSourced;
    public Label errorLabel;

    /**
     * This method updates the label to "Machine ID" when the in-house radio button is selected.
     *
     * @param actionEvent the action event triggered by selecting the in-house radio button
     */
    public void inHouseSelected(ActionEvent actionEvent) {
        idNameToggle.setText("Machine ID");
    }

    /**
     * This method updates the label to "Company Name" when the outsourced radio button is selected.
     *
     * @param actionEvent the action event triggered by selecting the outsourced radio button
     */
    public void outSourcedSelected(ActionEvent actionEvent) {
        idNameToggle.setText("Company Name");
    }

    /**
     * This method handles the data input and adds a new part to the inventory when the add button is pressed.
     * Displays an error alert if the data is invalid.
     *
     * @param actionEvent the action event triggered by pressing the add button
     * @throws IOException if an I/O error occurs during navigation
     */
    public void addButtonAction(ActionEvent actionEvent) throws IOException {
        int id = generateNewId();

        try {
            String name = nameSection.getText().trim();
            int stock = Integer.parseInt(inventorySection.getText().trim());
            double price = Double.parseDouble(priceSection.getText().trim());
            int min = Integer.parseInt(minSection.getText().trim());
            int max = Integer.parseInt(maxSection.getText().trim());

            if (min > max) {
                showAlert(Alert.AlertType.ERROR, "Error", "The min must be less than the max");
                return;
            }
            if (stock > max || stock < min) {
                showAlert(Alert.AlertType.ERROR, "Error", "Stock cannot be more than max or less than min");
                return;
            }

            if (inHouse.isSelected()) {
                int machineID = Integer.parseInt(idNameSection.getText().trim());
                Inventory.addPart(new InHouse(id, name, price, stock, min, max, machineID));
            } else if (outSourced.isSelected()) {
                String companyName = idNameSection.getText().trim();
                Inventory.addPart(new Outsourced(id, name, price, stock, min, max, companyName));
            }

            cancelButton(actionEvent);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid data entered");
        }
    }

    /**
     * This method generates a new unique ID for the part based on existing parts in the inventory.
     *
     * @return a unique ID for the new part
     */
    private int generateNewId() {
        int id = 0;
        for (int i = 0; i < Inventory.getAllParts().size(); i++) {
            if (id <= Inventory.getAllParts().get(i).getId()) {
                id = Inventory.getAllParts().get(i).getId() + 1;
            }
        }
        return id;
    }

    /**
     * This method returns the user to the Main.fxml view.
     *
     * @param actionEvent the action event triggered by pressing the cancel button
     * @throws IOException if an I/O error occurs during navigation
     */
    public void cancelButton(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Main.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 800, 450);
        stage.setTitle("Inventory Manager");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method displays an alert with the specified type, title, and content text.
     *
     * @param alertType the type of alert to display
     * @param title     the title of the alert
     * @param content   the content text of the alert
     */
    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
