package Controller;

import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller class for the ModifyProduct.fxml view.
 * Manages the functionality of modifying an existing product, including searching for parts, modifying product details, and managing associated parts.
 */
public class ModifyProductController implements Initializable {

    public TextField searchAssociatedParts;
    public TextField searchAvailableParts;
    public TableView<Part> partTable;
    public TableColumn<Part, Integer> partID;
    public TableColumn<Part, String> partName;
    public TableColumn<Part, Integer> partInventory;
    public TableColumn<Part, Double> partPrice;

    public TableView<Part> associatedPartTable;
    public TableColumn<Part, Integer> associatedPartID;
    public TableColumn<Part, String> associatedPartName;
    public TableColumn<Part, Integer> associatedPartInventory;
    public TableColumn<Part, Double> associatedPartPrice;

    public TextField inventorySection;
    public TextField nameSection;
    public TextField priceSection;
    public TextField minSection;
    public TextField maxSection;
    public TextField idSection;
    public Label errorLabel;
    public int mpIndex;

    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();

    /**
     * This method initializes the table columns and sets the initial data for the part and associated part tables.
     *
     * @param url           the URL location of the FXML file
     * @param resourceBundle the resource bundle containing locale-specific objects
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        partID.setCellValueFactory(new PropertyValueFactory<>("id"));
        partName.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        partTable.setItems(Inventory.getAllParts());

        associatedPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        associatedPartPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    /**
     * This method populates the fields and tables with data from the selected product.
     *
     * @param selectedProduct the product to be modified
     */
    public void sendProductData(Product selectedProduct) {
        associatedParts.setAll(selectedProduct.getAllAssociatedParts());
        associatedPartTable.setItems(associatedParts);

        idSection.setText(Integer.toString(selectedProduct.getId()));
        inventorySection.setText(Integer.toString(selectedProduct.getStock()));
        nameSection.setText(selectedProduct.getName());
        priceSection.setText(Double.toString(selectedProduct.getPrice()));
        minSection.setText(Integer.toString(selectedProduct.getMin()));
        maxSection.setText(Integer.toString(selectedProduct.getMax()));
        mpIndex = Inventory.getAllProducts().indexOf(selectedProduct);
    }

    /**
     * This method handles the data input and modifies the product when the modify button is pressed.
     *
     * @param actionEvent the action event triggered by pressing the modify button
     */
    public void modifyButtonAction(ActionEvent actionEvent) {
        try {
            int id = Integer.parseInt(idSection.getText().trim());
            String name = nameSection.getText().trim();
            int stock = Integer.parseInt(inventorySection.getText().trim());
            double price = Double.parseDouble(priceSection.getText().trim());
            int min = Integer.parseInt(minSection.getText().trim());
            int max = Integer.parseInt(maxSection.getText().trim());

            if (min > max) {
                showAlert(Alert.AlertType.ERROR, "Error", "The min must be less than the max");
                return;
            }

            if (stock > max || stock < min) {
                showAlert(Alert.AlertType.ERROR, "Error", "Stock cannot be more than max or less than min");
                return;
            }

            Product modifiedProduct = new Product(id, name, price, stock, min, max);
            modifiedProduct.setId(id);
            modifiedProduct.getAllAssociatedParts().setAll(associatedParts);
            Inventory.updateProduct(mpIndex, modifiedProduct);

            cancelButton(actionEvent);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid data entered");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to load the main view");
        }
    }

    /**
     * This method returns the user to the Main.fxml view.
     *
     * @param actionEvent the action event triggered by pressing the cancel button
     * @throws IOException if an I/O error occurs during navigation
     */
    public void cancelButton(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Main.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 800, 450);
        stage.setTitle("Inventory Manager");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method searches for associated parts based on user input in the search field.
     *
     * @param actionEvent the action event triggered by pressing the search button
     */
    public void searchAssociatedPartsAction(ActionEvent actionEvent) {
        String query = searchAssociatedParts.getText().trim();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        if (query.isEmpty()) {
            associatedPartTable.setItems(associatedParts);
            return;
        }

        if (query.matches("\\d+")) {
            int id = Integer.parseInt(query);
            for (Part part : associatedParts) {
                if (part.getId() == id) {
                    filteredParts.add(part);
                }
            }
        } else if (query.matches("[a-zA-Z]+")) {
            for (Part part : associatedParts) {
                if (part.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredParts.add(part);
                }
            }
        }

        associatedPartTable.setItems(filteredParts);
    }

    /**
     * This method searches for available parts based on user input in the search field.
     *
     * @param actionEvent the action event triggered by pressing the search button
     */
    public void searchAvailablePartsAction(ActionEvent actionEvent) {
        String query = searchAvailableParts.getText().trim();
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();

        if (query.isEmpty()) {
            partTable.setItems(Inventory.getAllParts());
        } else if (query.matches("\\d+")) {
            int id = Integer.parseInt(query);
            Part part = Inventory.lookupPartID(id);
            if (part != null) {
                filteredParts.add(part);
            }
            partTable.setItems(filteredParts);
        } else {
            partTable.setItems(Inventory.lookupPartName(query));
        }
    }

    /**
     * This method adds the selected part from the available parts table to the associated parts table.
     *
     * @param actionEvent the action event triggered by clicking the add button
     */
    public void addPartsButtonAction(ActionEvent actionEvent) {
        Part selectedPart = partTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            if (!associatedParts.contains(selectedPart)) {
                associatedParts.add(selectedPart);
                associatedPartTable.setItems(associatedParts);
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "The associated parts table already contains this part.");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Please make a selection.");
        }
    }

    /**
     * This method removes the selected part from the associated parts table.
     *
     * @param actionEvent the action event triggered by clicking the remove button
     */
    public void removePartsButtonAction(ActionEvent actionEvent) {
        Part selectedPart = associatedPartTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setContentText("Are you sure you want to remove this part?");
            alert.setHeaderText("Delete " + selectedPart.getName());
            Optional<ButtonType> result = alert.showAndWait();

            if (result.get() == ButtonType.OK) {
                associatedParts.remove(selectedPart);
                associatedPartTable.setItems(associatedParts);
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Error", "Please make a selection.");
        }
    }

    /**
     * This method displays an alert with the specified type, title, and content text.
     *
     * @param alertType the type of alert to display
     * @param title     the title of the alert
     * @param content   the content text of the alert
     */
    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}